"""Small behavioral checks for deterministic utilities; run once after edits."""

from __future__ import annotations

import csv
import json
import tempfile
import unittest
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from amount_reconcile import reconcile  # noqa: E402
from argument_graph import analyze  # noqa: E402
from case_inventory import make_inventory  # noqa: E402
from review_check import check_ledger  # noqa: E402
from review_bundle import REQUIRED, package_review  # noqa: E402
from timeline_audit import audit_timeline  # noqa: E402


class UtilityTests(unittest.TestCase):
    def test_review_bundle_requires_all_outputs_and_keeps_manifest(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            for name in REQUIRED[:-1]:
                (root / name).write_text("供承办律师复核。" * 20, encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "required regular file missing"):
                package_review(root)
            (root / REQUIRED[-1]).write_text("争点,动作\n" + "Q1,核原件\n" * 20, encoding="utf-8-sig")
            result = package_review(root)
            with zipfile.ZipFile(result["archive"]) as archive:
                self.assertEqual(set(archive.namelist()), set(REQUIRED) | {"manifest.json"})
            with self.assertRaisesRegex(ValueError, "archive already exists"):
                package_review(root)

    def test_inventory_detects_identical_files_without_following_symlink(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root / "a.jpg").write_bytes(b"sample")
            (root / "b.jpg").write_bytes(b"sample")
            (root / "link.jpg").symlink_to(root / "a.jpg")
            result = make_inventory(root)
            self.assertEqual(len(result["files"]), 2)
            self.assertEqual(result["identical_file_groups"], [["M0001", "M0002"]])
            self.assertTrue(any("symlink skipped" in w for w in result["warnings"]))

    def test_review_check_catches_untraceable_verified_issue(self) -> None:
        ledger = {"schema_version": "1.0", "issues": [{
            "id": "Q001", "question": "是否结清？", "status": "verified",
            "priority": "must_before_hearing", "source_refs": [],
            "authority_ids": [], "action_ids": [], "opponent_position": "否认"
        }], "authorities": [], "actions": []}
        result = check_ledger(ledger)
        self.assertFalse(result["ok"])
        self.assertTrue(any("verified issue has no cited material" in e for e in result["errors"]))

    def test_case_excerpt_cannot_be_marked_full_text_checked(self) -> None:
        ledger = {"schema_version": "1.0", "issues": [], "actions": [], "authorities": [{
            "id": "A001", "kind": "case", "citation": "（虚构）某号",
            "verification": "full_text_checked", "document_scope": "excerpt",
            "source_url": "https://example.invalid/fragment", "source_locator": "本院认为片段"
        }]}
        result = check_ledger(ledger)
        self.assertFalse(result["ok"])
        self.assertTrue(any("full opinion" in e for e in result["errors"]))

    def test_case_applicability_requires_decisive_comparison(self) -> None:
        ledger = {"schema_version": "1.0", "issues": [], "actions": [], "authorities": [{
            "id": "A001", "kind": "case", "citation": "（虚构）某号",
            "verification": "applicability_checked", "document_scope": "full_opinion",
            "source_url": "https://example.invalid/opinion", "source_locator": "裁判全文",
            "decisive_facts": "", "holding": "", "fit_reason": ""
        }]}
        result = check_ledger(ledger)
        self.assertFalse(result["ok"])
        self.assertTrue(any("decisive comparison" in e for e in result["errors"]))

    def test_amounts_use_decimal_and_reject_duplicate_entries(self) -> None:
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "amounts.csv"
            with path.open("w", encoding="utf-8", newline="") as stream:
                writer = csv.DictWriter(stream, fieldnames=["claim_id", "entry_id", "kind", "amount", "source_ref"])
                writer.writeheader()
                writer.writerow({"claim_id": "A", "entry_id": "1", "kind": "charge", "amount": "0.30", "source_ref": "M0001#p1"})
                writer.writerow({"claim_id": "A", "entry_id": "2", "kind": "payment", "amount": "0.10", "source_ref": "M0002#p1"})
            result = reconcile(path)
            self.assertEqual(result["balances"][0]["balance"], "0.20")
            self.assertTrue(result["ok"])

    def test_argument_graph_distinguishes_required_from_alternative_evidence(self) -> None:
        graph = {"schema_version": "1.0", "goals": ["R"], "nodes": [
            {"id": "R", "all_of": ["L", "F"]},
            {"id": "L"},
            {"id": "F", "any_of": ["E1", "E2"]},
            {"id": "E1"},
            {"id": "E2"},
        ]}
        result = analyze(graph)
        self.assertTrue(result["ok"])
        self.assertIn({"node_id": "L", "affected_goals": ["R"]}, result["single_point_failures"])
        self.assertNotIn({"node_id": "E1", "affected_goals": ["R"]}, result["single_point_failures"])
        self.assertIn(["E1", "E2"], result["minimal_primitive_cut_sets"]["R"])

    def test_argument_graph_rejects_cycle(self) -> None:
        graph = {"schema_version": "1.0", "goals": ["R"], "nodes": [
            {"id": "R", "all_of": ["A"]},
            {"id": "A", "all_of": ["R"]},
        ]}
        self.assertFalse(analyze(graph)["ok"])

    def test_timeline_audit_rejects_reversed_order(self) -> None:
        data = {"events": [
            {"id": "E1", "occurred_at": "2025-08-08T11:47:45+08:00", "source_ref": "M1 p1"},
            {"id": "E2", "occurred_at": "2025-08-08T12:40:03+08:00", "source_ref": "M2 p11"},
        ], "order_claims": [{"earlier": "E2", "later": "E1", "claim_ref": "draft p2"}]}
        result = audit_timeline(data)
        self.assertFalse(result["ok"])
        self.assertEqual(len(result["contradictions"]), 1)

    def test_timeline_audit_keeps_date_only_order_unresolved(self) -> None:
        data = {"events": [
            {"id": "E1", "occurred_at": "2025-08-08", "source_ref": "M1 p1"},
            {"id": "E2", "occurred_at": "2025-08-08T12:40:03+08:00", "source_ref": "M2 p11"},
        ], "order_claims": [{"earlier": "E1", "later": "E2", "claim_ref": "draft p2"}]}
        result = audit_timeline(data)
        self.assertTrue(result["ok"])
        self.assertEqual(len(result["unresolved"]), 1)

    def test_timeline_audit_reports_malformed_event_reference(self) -> None:
        data = {"events": [{"id": "E1", "occurred_at": "2025-08-08", "source_ref": "M1 p1"}],
                "order_claims": [{"earlier": ["E1"], "later": "E1", "claim_ref": "draft"}]}
        result = audit_timeline(data)
        self.assertFalse(result["ok"])
        self.assertTrue(result["errors"])


if __name__ == "__main__":
    unittest.main()
