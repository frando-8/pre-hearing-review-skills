"""Package completed internal review files without changing source evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import zipfile


REQUIRED = (
    "庭前复核工作底稿.md",
    "对方进攻与庭审答法.md",
    "正反案例检索备忘.md",
    "庭前行动表.csv",
)


def package_review(folder: Path, output: Path | None = None) -> dict:
    folder = folder.resolve()
    if not folder.is_dir():
        raise ValueError(f"output directory does not exist: {folder}")
    output = output or folder / "庭前复核成果.zip"
    output = output.resolve()
    if output.exists():
        raise ValueError(f"archive already exists: {output}")
    if output.parent != folder:
        raise ValueError("archive must be written inside the reviewed output directory")

    records = []
    for name in REQUIRED:
        path = folder / name
        if not path.is_file() or path.is_symlink():
            raise ValueError(f"required regular file missing: {name}")
        data = path.read_bytes()
        if len(data) < 100:
            raise ValueError(f"file is unexpectedly short: {name}")
        data.decode("utf-8-sig")
        records.append({"name": name, "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

    manifest = {"schema_version": "1.0", "purpose": "internal_lawyer_review", "files": records,
                "warning": "Hashes verify packaged bytes, not legal accuracy or source completeness."}
    try:
        with zipfile.ZipFile(output, "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for record in records:
                archive.write(folder / record["name"], record["name"])
            archive.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    except Exception:
        output.unlink(missing_ok=True)
        raise
    return {"archive": str(output), "manifest": manifest}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path, help="directory containing the four completed review files")
    args = parser.parse_args()
    try:
        result = package_review(args.folder)
    except (ValueError, OSError, UnicodeError) as exc:
        print(f"review_bundle: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
