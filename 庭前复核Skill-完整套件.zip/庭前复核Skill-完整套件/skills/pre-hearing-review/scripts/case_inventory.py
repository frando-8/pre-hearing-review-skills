#!/usr/bin/env python3
"""Read-only local case-file inventory. Python 3.10+, standard library only.

The tool never extracts or uploads document content. It reports paths, hashes,
sizes, guessed media types, duplicate files and optional PDF page counts.
Output is stdout unless --output is explicitly provided.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import mimetypes
import os
import shutil
import subprocess
import sys
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SKIP_DIRS = {".git", ".DS_Store", "__pycache__", ".venv", "node_modules"}
PDF_SUFFIXES = {".pdf"}
IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".tif", ".tiff", ".heic", ".webp", ".bmp"}


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def pdf_pages(path: Path) -> int | None:
    command = shutil.which("pdfinfo")
    if not command:
        return None
    try:
        result = subprocess.run(
            [command, str(path)], capture_output=True, text=True, timeout=20, check=False
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode:
        return None
    for line in result.stdout.splitlines():
        if line.lower().startswith("pages:"):
            try:
                return int(line.split(":", 1)[1].strip())
            except ValueError:
                return None
    return None


def image_dimensions(path: Path) -> tuple[int, int] | None:
    command = shutil.which("sips")
    if not command:
        return None
    try:
        result = subprocess.run(
            [command, "-g", "pixelWidth", "-g", "pixelHeight", str(path)],
            capture_output=True, text=True, timeout=20, check=False
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    if result.returncode:
        return None
    values: dict[str, int] = {}
    for line in result.stdout.splitlines():
        key, separator, value = line.strip().partition(":")
        if separator and key in {"pixelWidth", "pixelHeight"}:
            try:
                values[key] = int(value.strip())
            except ValueError:
                return None
    if "pixelWidth" in values and "pixelHeight" in values:
        return values["pixelWidth"], values["pixelHeight"]
    return None


def classify(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in PDF_SUFFIXES:
        return "pdf"
    if suffix in IMAGE_SUFFIXES:
        return "image"
    if suffix in {".doc", ".docx", ".odt", ".rtf"}:
        return "word_processing"
    if suffix in {".xls", ".xlsx", ".csv", ".ods"}:
        return "spreadsheet"
    if suffix in {".txt", ".md", ".eml", ".msg"}:
        return "text_or_message"
    if suffix in {".mp3", ".m4a", ".wav", ".mp4", ".mov"}:
        return "audio_video"
    return "other"


def make_inventory(root: Path, *, hash_files: bool = True) -> dict[str, Any]:
    root = root.resolve(strict=True)
    if not root.is_dir():
        raise ValueError("input must be a directory")
    files: list[dict[str, Any]] = []
    warnings: list[str] = []
    for current, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS and not (Path(current) / d).is_symlink())
        for name in sorted(names):
            path = Path(current) / name
            relative = path.relative_to(root).as_posix()
            if path.is_symlink():
                warnings.append(f"symlink skipped: {relative}")
                continue
            if not path.is_file():
                continue
            try:
                stat = path.stat()
                entry: dict[str, Any] = {
                    "id": f"M{len(files) + 1:04d}",
                    "relative_path": relative,
                    "size_bytes": stat.st_size,
                    "modified_utc": datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
                    "kind": classify(path),
                    "mime_guess": mimetypes.guess_type(path.name)[0],
                    "sha256": sha256_file(path) if hash_files else None,
                    "pdf_pages": pdf_pages(path) if path.suffix.lower() == ".pdf" else None,
                    "image_pixels": image_dimensions(path) if path.suffix.lower() in IMAGE_SUFFIXES else None,
                    "submission_state": "unknown",
                    "read_state": "not_read",
                }
                files.append(entry)
            except (OSError, PermissionError) as exc:
                warnings.append(f"could not read {relative}: {type(exc).__name__}")
    by_hash: dict[str, list[str]] = defaultdict(list)
    for item in files:
        if item["sha256"]:
            by_hash[item["sha256"]].append(item["id"])
    duplicates = [ids for ids in by_hash.values() if len(ids) > 1]
    return {
        "schema_version": "1.0",
        "root": str(root),
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "files": files,
        "identical_file_groups": duplicates,
        "warnings": warnings,
        "note": "Metadata inventory only. File content, authenticity, version and submission status require lawyer review.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("case_dir", type=Path, help="local case folder")
    parser.add_argument("--output", type=Path, help="write JSON here; stdout is the default")
    parser.add_argument("--no-hash", action="store_true", help="skip SHA-256 for speed")
    args = parser.parse_args()
    try:
        result = make_inventory(args.case_dir, hash_files=not args.no_hash)
    except (OSError, ValueError) as exc:
        print(f"inventory error: {exc}", file=sys.stderr)
        return 2
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        try:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        except OSError as exc:
            print(f"output error: {exc}", file=sys.stderr)
            return 2
    else:
        sys.stdout.write(payload)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
