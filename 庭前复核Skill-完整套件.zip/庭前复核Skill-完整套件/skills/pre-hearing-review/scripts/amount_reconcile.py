#!/usr/bin/env python3
"""Reconcile lawyer-classified claim amounts with Decimal arithmetic.

CSV columns: claim_id,entry_id,kind,amount,source_ref. Kinds: charge,
increase, payment, decrease. The script checks arithmetic and duplicate IDs;
it cannot decide whether a payment legally belongs to a claim. Local only.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from decimal import Decimal, InvalidOperation
from pathlib import Path
from typing import Any


SIGN = {"charge": 1, "increase": 1, "payment": -1, "decrease": -1}
FIELDS = {"claim_id", "entry_id", "kind", "amount", "source_ref"}


def reconcile(path: Path) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    totals: dict[str, Decimal] = defaultdict(lambda: Decimal("0"))
    count: dict[str, int] = defaultdict(int)
    seen: set[str] = set()
    with path.open(newline="", encoding="utf-8-sig") as stream:
        reader = csv.DictReader(stream)
        missing = FIELDS - set(reader.fieldnames or [])
        if missing:
            return {"ok": False, "errors": [f"missing columns: {', '.join(sorted(missing))}"], "warnings": []}
        for row_number, row in enumerate(reader, start=2):
            claim = (row.get("claim_id") or "").strip()
            entry = (row.get("entry_id") or "").strip()
            kind = (row.get("kind") or "").strip()
            source = (row.get("source_ref") or "").strip()
            if not claim or not entry:
                errors.append(f"row {row_number}: claim_id and entry_id required")
                continue
            if entry in seen:
                errors.append(f"row {row_number}: duplicate entry_id {entry}")
            seen.add(entry)
            if kind not in SIGN:
                errors.append(f"row {row_number}: invalid kind {kind!r}")
                continue
            try:
                amount = Decimal((row.get("amount") or "").strip())
            except InvalidOperation:
                errors.append(f"row {row_number}: invalid amount")
                continue
            if not amount.is_finite() or amount < 0:
                errors.append(f"row {row_number}: amount must be finite and nonnegative")
                continue
            if not source:
                warnings.append(f"row {row_number}: missing source_ref")
            totals[claim] += SIGN[kind] * amount
            count[claim] += 1
    return {
        "ok": not errors,
        "errors": errors,
        "warnings": warnings,
        "balances": [{"claim_id": key, "balance": format(value, "f"), "entries": count[key]}
                     for key, value in sorted(totals.items())],
        "note": "Arithmetic only; allocation, legal nature, interest and tax require separate evidence and legal review.",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("csv_file", type=Path)
    parser.add_argument("--output", type=Path, help="write JSON; stdout by default")
    args = parser.parse_args()
    try:
        result = reconcile(args.csv_file)
    except OSError as exc:
        print(f"amount check error: {exc}", file=sys.stderr)
        return 2
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        try:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        except OSError as exc:
            print(f"output error: {exc}", file=sys.stderr)
            return 2
    else:
        sys.stdout.write(payload)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
