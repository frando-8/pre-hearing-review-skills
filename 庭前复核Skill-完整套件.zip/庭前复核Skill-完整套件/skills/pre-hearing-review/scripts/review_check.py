#!/usr/bin/env python3
"""Check a local review ledger for missing links and unsupported assertions.

This checks structure and traceability, not legal correctness. It reads JSON
locally, makes no network calls, and writes only when --output is supplied.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any


ISSUE_STATES = {"verified", "partial", "lead", "undetermined"}
AUTHORITY_STATES = {"candidate", "full_text_checked", "applicability_checked"}
PRIORITIES = {"must_before_hearing", "prepare_response", "reference"}


def ids_of(rows: Any, label: str, errors: list[str]) -> set[str]:
    if not isinstance(rows, list):
        errors.append(f"{label} must be an array")
        return set()
    ids: set[str] = set()
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or not isinstance(row.get("id"), str) or not row["id"].strip():
            errors.append(f"{label}[{index}] needs a nonempty id")
            continue
        if row["id"] in ids:
            errors.append(f"duplicate {label} id: {row['id']}")
        ids.add(row["id"])
    return ids


def check_ledger(data: Any, inventory: Any | None = None) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []
    if not isinstance(data, dict):
        return {"ok": False, "errors": ["ledger root must be an object"], "warnings": []}
    if data.get("schema_version") != "1.0":
        errors.append("schema_version must be 1.0")
    issues = data.get("issues", [])
    actions = data.get("actions", [])
    authorities = data.get("authorities", [])
    issue_ids = ids_of(issues, "issues", errors)
    action_ids = ids_of(actions, "actions", errors)
    authority_ids = ids_of(authorities, "authorities", errors)
    material_ids: set[str] | None = None
    if inventory is not None:
        if not isinstance(inventory, dict) or not isinstance(inventory.get("files"), list):
            errors.append("inventory must have a files array")
        else:
            material_ids = ids_of(inventory["files"], "inventory.files", errors)

    for issue in issues if isinstance(issues, list) else []:
        if not isinstance(issue, dict) or not isinstance(issue.get("id"), str):
            continue
        iid = issue["id"]
        if not str(issue.get("question", "")).strip():
            errors.append(f"{iid}: missing question")
        if issue.get("status") not in ISSUE_STATES:
            errors.append(f"{iid}: invalid status")
        if issue.get("priority") not in PRIORITIES:
            errors.append(f"{iid}: invalid priority")
        refs = issue.get("source_refs", [])
        if not isinstance(refs, list):
            errors.append(f"{iid}: source_refs must be an array")
            refs = []
        if not refs:
            warnings.append(f"{iid}: no source_refs; mark as a lead and state the basis")
        for ref in refs:
            if not isinstance(ref, dict) or not ref.get("material_id"):
                errors.append(f"{iid}: each source_ref needs material_id")
                continue
            if material_ids is not None and ref["material_id"] not in material_ids:
                errors.append(f"{iid}: unknown material {ref['material_id']}")
            if not str(ref.get("locator", "")).strip():
                warnings.append(f"{iid}: source {ref['material_id']} lacks page/region locator")
        authority_refs = issue.get("authority_ids", [])
        if not isinstance(authority_refs, list):
            errors.append(f"{iid}: authority_ids must be an array")
            authority_refs = []
        for aid in authority_refs:
            if aid not in authority_ids:
                errors.append(f"{iid}: unknown authority {aid}")
        action_refs = issue.get("action_ids", [])
        if not isinstance(action_refs, list):
            errors.append(f"{iid}: action_ids must be an array")
            action_refs = []
        for aid in action_refs:
            if aid not in action_ids:
                errors.append(f"{iid}: unknown action {aid}")
        if issue.get("priority") == "must_before_hearing" and not action_refs:
            warnings.append(f"{iid}: urgent issue has no action")
        if issue.get("status") == "verified" and not refs:
            errors.append(f"{iid}: verified issue has no cited material")
        if not str(issue.get("opponent_position", "")).strip():
            warnings.append(f"{iid}: no opponent position recorded")

    for authority in authorities if isinstance(authorities, list) else []:
        if not isinstance(authority, dict) or not isinstance(authority.get("id"), str):
            continue
        aid = authority["id"]
        if authority.get("verification") not in AUTHORITY_STATES:
            errors.append(f"{aid}: invalid verification state")
        if authority.get("kind") not in {"statute", "case", "other"}:
            errors.append(f"{aid}: invalid kind")
        if not str(authority.get("citation", "")).strip():
            errors.append(f"{aid}: missing citation")
        if authority.get("verification") != "candidate" and not authority.get("source_url"):
            warnings.append(f"{aid}: checked authority lacks source_url")
        if authority.get("kind") == "case":
            state = authority.get("verification")
            scope = authority.get("document_scope")
            if scope is not None and scope not in {"metadata", "excerpt", "full_opinion"}:
                errors.append(f"{aid}: invalid case document_scope")
            if state in {"full_text_checked", "applicability_checked"}:
                if scope != "full_opinion" or not str(authority.get("source_locator", "")).strip():
                    errors.append(f"{aid}: full opinion and source locator required for checked case")
            if state == "applicability_checked":
                if not all(str(authority.get(key, "")).strip() for key in ("decisive_facts", "holding", "fit_reason")):
                    errors.append(f"{aid}: decisive comparison required for case applicability")

    for action in actions if isinstance(actions, list) else []:
        if not isinstance(action, dict) or not isinstance(action.get("id"), str):
            continue
        aid = action["id"]
        if not str(action.get("task", "")).strip():
            errors.append(f"{aid}: missing task")
        linked_issues = action.get("issue_ids", [])
        if not isinstance(linked_issues, list):
            errors.append(f"{aid}: issue_ids must be an array")
            linked_issues = []
        if not linked_issues:
            warnings.append(f"{aid}: action is not linked to an issue")
        for iid in linked_issues:
            if iid not in issue_ids:
                errors.append(f"{aid}: unknown issue {iid}")
        if not str(action.get("completion_condition", "")).strip():
            warnings.append(f"{aid}: no completion_condition")

    return {"ok": not errors, "errors": errors, "warnings": warnings, "counts": {
        "issues": len(issues) if isinstance(issues, list) else 0,
        "authorities": len(authorities) if isinstance(authorities, list) else 0,
        "actions": len(actions) if isinstance(actions, list) else 0,
    }}


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ledger", type=Path)
    parser.add_argument("--inventory", type=Path, help="optional case_inventory.py output")
    parser.add_argument("--output", type=Path, help="write findings as JSON; stdout by default")
    args = parser.parse_args()
    try:
        result = check_ledger(load_json(args.ledger), load_json(args.inventory) if args.inventory else None)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"review check error: {exc}", file=sys.stderr)
        return 2
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        try:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        except OSError as exc:
            print(f"output error: {exc}", file=sys.stderr)
            return 2
    else:
        sys.stdout.write(payload)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
