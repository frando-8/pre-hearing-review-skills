#!/usr/bin/env python3
"""Audit asserted event order against cited, timezone-aware timestamps.

The script never extracts dates from evidence. A lawyer or Codex must enter
events after checking the source image or record. It verifies chronology only;
it cannot establish identity, payment purpose, causation, or authenticity.
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any


def _instant(value: Any) -> datetime | None:
    if not isinstance(value, str) or "T" not in value:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    return parsed if parsed.tzinfo is not None and parsed.utcoffset() is not None else None


def audit_timeline(data: Any) -> dict[str, Any]:
    errors: list[str] = []
    contradictions: list[dict[str, str]] = []
    unresolved: list[dict[str, str]] = []
    if not isinstance(data, dict):
        return {"ok": False, "errors": ["root must be an object"], "contradictions": [], "unresolved": []}
    events = data.get("events")
    claims = data.get("order_claims")
    if not isinstance(events, list) or not isinstance(claims, list):
        return {"ok": False, "errors": ["events and order_claims must be arrays"], "contradictions": [], "unresolved": []}

    by_id: dict[str, dict[str, Any]] = {}
    for index, event in enumerate(events):
        if not isinstance(event, dict):
            errors.append(f"events[{index}] must be an object")
            continue
        event_id = event.get("id")
        if not isinstance(event_id, str) or not event_id.strip() or event_id in by_id:
            errors.append(f"events[{index}] needs a unique nonempty id")
            continue
        if not str(event.get("source_ref", "")).strip():
            errors.append(f"{event_id}: source_ref required")
        if not isinstance(event.get("occurred_at"), str) or not event["occurred_at"].strip():
            errors.append(f"{event_id}: occurred_at required")
        by_id[event_id] = event

    for index, claim in enumerate(claims):
        if not isinstance(claim, dict):
            errors.append(f"order_claims[{index}] must be an object")
            continue
        earlier, later = claim.get("earlier"), claim.get("later")
        if (not isinstance(earlier, str) or not isinstance(later, str)
                or earlier not in by_id or later not in by_id or earlier == later):
            errors.append(f"order_claims[{index}] refers to unknown or identical events")
            continue
        if not str(claim.get("claim_ref", "")).strip():
            errors.append(f"order_claims[{index}]: claim_ref required")
        first = _instant(by_id[earlier].get("occurred_at"))
        second = _instant(by_id[later].get("occurred_at"))
        record = {"earlier": earlier, "later": later, "claim_ref": str(claim.get("claim_ref", ""))}
        if first is None or second is None:
            record["reason"] = "missing full timestamp or timezone; inspect source"
            unresolved.append(record)
        elif first >= second:
            record["reason"] = "asserted order contradicts timestamps"
            contradictions.append(record)

    return {"ok": not errors and not contradictions, "errors": errors,
            "contradictions": contradictions, "unresolved": unresolved,
            "counts": {"events": len(events), "order_claims": len(claims)}}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("input", type=Path, help="JSON with events and order_claims")
    args = parser.parse_args()
    try:
        data = json.loads(args.input.read_text(encoding="utf-8"))
    except (OSError, ValueError) as exc:
        print(f"timeline audit error: {exc}", file=sys.stderr)
        return 2
    result = audit_timeline(data)
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
