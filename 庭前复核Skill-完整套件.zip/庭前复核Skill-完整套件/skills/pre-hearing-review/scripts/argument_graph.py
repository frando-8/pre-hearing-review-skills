#!/usr/bin/env python3
"""Analyze explicitly modeled argument dependencies without legal prediction.

Input nodes use all_of (every prerequisite) and any_of (at least one route).
The lawyer/agent defines the graph; the program only finds logical single-point
failures and small minimal cut sets. No network, OCR, or file writes by default.
"""

from __future__ import annotations

import argparse
import itertools
import json
import sys
from pathlib import Path
from typing import Any


def validate_graph(data: Any) -> tuple[dict[str, dict[str, Any]], list[str], list[str]]:
    errors: list[str] = []
    if not isinstance(data, dict) or data.get("schema_version") != "1.0":
        return {}, [], ["graph root must have schema_version 1.0"]
    rows = data.get("nodes")
    goals = data.get("goals")
    if not isinstance(rows, list) or not isinstance(goals, list) or not goals:
        return {}, [], ["nodes must be an array and goals a nonempty array"]
    nodes: dict[str, dict[str, Any]] = {}
    for index, row in enumerate(rows):
        if not isinstance(row, dict) or not isinstance(row.get("id"), str) or not row["id"]:
            errors.append(f"nodes[{index}] lacks id")
            continue
        nid = row["id"]
        if nid in nodes:
            errors.append(f"duplicate node id: {nid}")
        for field in ("all_of", "any_of"):
            if field not in row:
                row[field] = []
            if not isinstance(row[field], list) or any(not isinstance(x, str) for x in row[field]):
                errors.append(f"{nid}: {field} must be an array of ids")
                row[field] = []
        nodes[nid] = row
    for goal in goals:
        if goal not in nodes:
            errors.append(f"unknown goal: {goal}")
    for nid, row in nodes.items():
        for child in row["all_of"] + row["any_of"]:
            if child not in nodes:
                errors.append(f"{nid}: unknown prerequisite {child}")
            if child == nid:
                errors.append(f"{nid}: self-dependency")
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(nid: str) -> None:
        if nid in visiting:
            errors.append(f"cycle detected at {nid}")
            return
        if nid in visited or nid not in nodes:
            return
        visiting.add(nid)
        for child in nodes[nid]["all_of"] + nodes[nid]["any_of"]:
            visit(child)
        visiting.remove(nid)
        visited.add(nid)

    for nid in nodes:
        visit(nid)
    return nodes, goals, sorted(set(errors))


def viability(nodes: dict[str, dict[str, Any]], goal: str, failed: set[str]) -> bool:
    cache: dict[str, bool] = {}

    def walk(nid: str) -> bool:
        if nid in cache:
            return cache[nid]
        row = nodes[nid]
        result = (
            nid not in failed
            and all(walk(child) for child in row["all_of"])
            and (not row["any_of"] or any(walk(child) for child in row["any_of"]))
        )
        cache[nid] = result
        return result

    return walk(goal)


def analyze(data: Any, *, failed: set[str] | None = None,
            max_cut_size: int = 2, combination_limit: int = 5000) -> dict[str, Any]:
    nodes, goals, errors = validate_graph(data)
    failed = failed or set()
    for nid in failed:
        if nid not in nodes:
            errors.append(f"unknown failed node: {nid}")
    if errors:
        return {"ok": False, "errors": sorted(set(errors))}
    if max_cut_size not in {1, 2, 3}:
        return {"ok": False, "errors": ["max_cut_size must be 1, 2, or 3"]}
    if combination_limit < 1:
        return {"ok": False, "errors": ["combination_limit must be positive"]}
    baseline = {goal: viability(nodes, goal, failed) for goal in goals}
    primitives = sorted(nid for nid, row in nodes.items()
                        if not row["all_of"] and not row["any_of"] and nid not in goals)
    single_impact = []
    for nid in sorted(nodes):
        if nid in goals or nid in failed:
            continue
        affected = [goal for goal in goals if baseline[goal] and not viability(nodes, goal, failed | {nid})]
        if affected:
            single_impact.append({"node_id": nid, "affected_goals": affected})
    cuts: dict[str, list[list[str]]] = {goal: [] for goal in goals}
    examined = 0
    truncated = False
    for size in range(1, max_cut_size + 1):
        for group in itertools.combinations((nid for nid in primitives if nid not in failed), size):
            examined += 1
            if examined > combination_limit:
                truncated = True
                break
            new_failed = failed | set(group)
            for goal in goals:
                if not baseline[goal]:
                    continue
                if any(set(previous).issubset(group) for previous in cuts[goal]):
                    continue
                if not viability(nodes, goal, new_failed):
                    cuts[goal].append(list(group))
        if truncated:
            break
    return {
        "ok": True,
        "baseline_viable": baseline,
        "assumed_failed": sorted(failed),
        "single_point_failures": single_impact,
        "minimal_primitive_cut_sets": cuts,
        "combinations_examined": min(examined, combination_limit),
        "truncated": truncated,
        "note": "Logical dependency audit only. Node truth, legal necessity and evidence quality require human legal review."
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("graph", type=Path)
    parser.add_argument("--failed", action="append", default=[], help="node assumed unavailable; repeatable")
    parser.add_argument("--max-cut-size", type=int, choices=(1, 2, 3), default=2)
    parser.add_argument("--combination-limit", type=int, default=5000)
    parser.add_argument("--output", type=Path, help="write JSON; stdout by default")
    args = parser.parse_args()
    try:
        data = json.loads(args.graph.read_text(encoding="utf-8"))
        result = analyze(data, failed=set(args.failed), max_cut_size=args.max_cut_size,
                         combination_limit=args.combination_limit)
    except (OSError, ValueError) as exc:
        print(f"argument graph error: {exc}", file=sys.stderr)
        return 2
    payload = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        try:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(payload, encoding="utf-8")
        except OSError as exc:
            print(f"output error: {exc}", file=sys.stderr)
            return 2
    else:
        sys.stdout.write(payload)
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
